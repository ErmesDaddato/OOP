package interfacce;

import entita.Team;

public interface PunteggioStrategy {

    public int calcolaPunteggio(Team team);
}
